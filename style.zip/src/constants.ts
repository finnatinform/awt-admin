export class Constants{
    static  SERVER_URL : string = "http://localhost:9000/"; // http://ec2-52-59-201-86.eu-central-1.compute.amazonaws.com:9000/
}