import AppActionTypes = require('./app-action-types');

class AppAction {
    actionType : AppActionTypes ;
    data : any ;
}

export = AppAction ;