enum AppPageType {
    PT_EVENTS,
    PT_NOTIFICATIONS,
    PT_REFERENTS,
    PT_COMPANIES
}

export = AppPageType ;